﻿namespace Enum
{
    enum Pessoas
    {
        Giovanna,
        Julia,
        João,
        Gustavo,
        Mariana
    }
}
