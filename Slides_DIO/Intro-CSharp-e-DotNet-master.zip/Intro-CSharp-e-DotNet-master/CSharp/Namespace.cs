﻿namespace Primeiro
{
    class Classe
    {

    }
}

namespace Segundo
{
    class Classe
    {

    }
}