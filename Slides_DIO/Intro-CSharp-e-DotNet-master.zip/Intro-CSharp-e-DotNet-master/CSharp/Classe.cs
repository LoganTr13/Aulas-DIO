﻿namespace Classes
{
    class Pessoa
    {
        public string Nome { get; set; }
        public string Estado { get; set; }
        public int Idade { get; set; }
    }
}
